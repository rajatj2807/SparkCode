import findspark
findspark.init()
from pyspark.sql import SparkSession
import datetime
import pyspark.sql.functions as f
import os
import  us
import logging
from pyspark.sql import SQLContext
from config import config, source_header,target_header, s3_input_path, s3_output_path
from pyspark.sql.functions import sha2, concat_ws
from pyspark.sql.functions import to_date, to_timestamp, unix_timestamp, to_date, udf,col, lit, broadcast



class L2_Normalizer():
    def __init__(self, delimiter='|'):
        self.spark = None
        self.sqlContext = None
        self.fec_df = None
        self.partition_column = "ZIP_code"
        self.input_path = s3_input_path
        self.output_path = s3_output_path
        self.delimiter = delimiter
        self.access_key = os.environ['AWS_ACCESS_KEY_ID']
        self.secret_key = os.environ['AWS_SECRET_ACCESS_KEY']
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.getLevelName('DEBUG'))
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(
            '%(asctime)s %(name)-12s %(levelname)-8s %(message)s'))
        self.logger.addHandler(handler)

    def create_connection(self):
        self.logger.debug('Creation connection')
        self.spark = SparkSession.builder \
            .appName("my_app") \
            .config("spark.executor.memory", "6g") \
            .config("spark.driver.memory", "6g").config("spark.memory.offHeap.enabled", True) \
            .config("spark.memory.offHeap.size", "6g") \
            .config("spark.network.timeout", "36000s").getOrCreate()
        sc = self.spark.sparkContext
        self.sqlContext = SQLContext(sc)
        self.spark.conf.set("fs.s3a.access.key", self.access_key)
        self.spark.conf.set("fs.s3a.secret.key", self.secret_key)
        self.spark.conf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        self.spark.conf.set("fs.s3a.endpoint", "s3.us-east-1.amazonaws.com")
        self.spark.sparkContext.setSystemProperty("com.amazonaws.services.s3.enableV4", "true")

    def read_data(self):
        self.create_connection()
        self.logger.debug('Reading Raw Data')

        self.l2_df = self.spark.read.parquet(self.input_path).select(*source_header)
        self.l2_df = self.l2_df.toDF(*target_header)
        self.l2_df = self.l2_df.withColumn("State_Validation", lit("false"))



    def normalize_date(self):
        self.logger.debug('Normalizing date')
        for i in config['mapping_json']:
            if config['mapping_json'][i]["type"] == "timestamp":
                self.l2_df = self.l2_df.withColumn(i,
                                                     to_timestamp(self.l2_df[i], "MM/dd/yyyy").cast("string"))
                self.l2_df = self.l2_df.na.fill("NULL")


    @staticmethod
    def validate_state(data):
        try:
            state_check = us.states.lookup(data["Residence_Addresses_State"])
            if state_check != None:
                data["Residence_Addresses_State"] = state_check.abbr
                data['State_Validation'] = "true"
            else:
                data["State_Validation"] = "false"
            return data
        except:
            return data

    def normalize_state(self):
        self.logger.debug('Normalizing state')
        validate_l2_data_rdd = self.l2_df.rdd.map(lambda row: L2_Normalizer.validate_state(row.asDict()))

        self.l2_df = self.spark.createDataFrame(validate_l2_data_rdd, self.l2_df.schema)


    def unique_identity(self):
        self.logger.debug('Unique Identity')

        count_df = self.l2_df.cube("Voters_Statevoterid").count()
        self.l2_df = self.l2_df.join(count_df, ["Voters_Statevoterid"])


    def write_data_file(self):
        self.logger.debug('Writing data')
        start_time = datetime.datetime.now()

        #writing data to csv format
        self.l2_df=self.l2_df.select([col(c).cast("string") for c in self.l2_df.columns])
        #self.l2_df.printSchema()

        self.l2_df.coalesce(1).write.csv(path=self.output_path, header="true", mode="append")

        end_time = datetime.datetime.now()
        self.logger.debug('Time taken to write file')
        self.logger.debug(end_time-start_time)

    def close(self):
        self.logger.debug('Process_closed')
        self.spark.stop()
