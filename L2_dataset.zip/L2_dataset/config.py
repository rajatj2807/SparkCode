import os
import json
source_header=[]
target_header=[]
input_path=""
output_path=""
#
with open('l2_mapping.json', 'r') as f:
    config = json.load(f)

#Source Header
for i in config['mapping_json']:
    source_header.append(i)

#Targer Header
for i in config['mapping_json']:
    target_header.append(config['mapping_json'][i]['name'])

#S3 input
s3_input_path=config['s3_input_path']
s3_output_path=config['s3_output_path']
