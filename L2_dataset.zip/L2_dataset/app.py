from L2_normalize import L2_Normalizer


def run_normalizer():
    l2_normalizer = L2_Normalizer()

    l2_normalizer.read_data()
    l2_normalizer.normalize_date()
    l2_normalizer.normalize_state()
    l2_normalizer.unique_identity()

    l2_normalizer.write_data_file()

    l2_normalizer.close()


if __name__ == '__main__':
    run_normalizer()
