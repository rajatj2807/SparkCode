from normalize.Fec_Normalizer import Fec_Normalizer


def run_normalizer():
    fec_normalizer = Fec_Normalizer()

    fec_normalizer.read_data()
    fec_normalizer.normalize_date()
    fec_normalizer.normalize_name()
    fec_normalizer.normalize_state()
    fec_normalizer.unique_identity()

    fec_normalizer.write_data_file()

    fec_normalizer.close()


if __name__ == '__main__':
    run_normalizer()
