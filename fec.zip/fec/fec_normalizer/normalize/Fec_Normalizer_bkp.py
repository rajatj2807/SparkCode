import findspark
findspark.init()
import pandas as pd
from pyspark import SparkContext
from pyspark.sql import SparkSession
import  us
import pyspark.sql.functions as f
import os

from pyspark.sql import SQLContext
import datetime
from pyspark.sql.functions import sha2, concat_ws
from config import config, target_header, s3_input_path, s3_output_path
from pyspark.sql.functions import to_date, to_timestamp, unix_timestamp, to_date, udf,col,lit



class Fec_Normalizer():
    def __init__(self, delimiter='|'):
        self.spark = None
        self.sqlContext = None
        self.fec_df = None
        self.partition_column = "ZIP_code"
        self.target_header = target_header
        self.input_path = s3_input_path
        self.output_path = s3_output_path
        self.delimiter = delimiter
        self.partition_column = config['partition_column']
        self.s3_anonymous_state_output_path = config['s3_anonymous_state_output_path']
        self.access_key = os.environ['AWS_ACCESS_KEY_ID']
        self.secret_key = os.environ['AWS_SECRET_ACCESS_KEY']


    def create_connection(self):
        self.spark = SparkSession.builder \
            .appName("my_app") \
            .config("spark.executor.memory", "6g") \
            .config("spark.driver.memory", "6g") \
            .config("spark.memory.offHeap.size", "6g")\
            .config("spark.network.timeout", "600s").getOrCreate()

        sc = self.spark.sparkContext


        self.sqlContext = SQLContext(sc)

        self.spark.conf.set("fs.s3a.access.key", self.access_key)

        self.spark.conf.set("fs.s3a.secret.key", self.secret_key)

        self.spark.conf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")

        self.spark.conf.set("fs.s3a.endpoint", "s3.us-east-1.amazonaws.com")
        self.spark.sparkContext.setSystemProperty("com.amazonaws.services.s3.enableV4", "true")

    def read_data(self):
        self.create_connection()
        print(self.target_header)

        if len(self.input_path.split(',')) > 1:
            self.fec_df = self.spark.read.format("csv").option("header", "false").option('delimiter',
                                                                                         self.delimiter).option(
                'mode', 'DROPMALFORMED').load(self.input_path.split(','))
        else:
            self.fec_df = self.spark.read.format("csv").option("header", "false").option('delimiter',
                                                                                         self.delimiter).option(
                'mode', 'DROPMALFORMED').load(self.input_path)
        self.fec_df = self.fec_df.toDF(*self.target_header)
        self.fec_df = self.fec_df.withColumn("State_Validation", lit("false"))
        self.fec_df = self.fec_df.na.fill("NULL")
        print("count of data")
        #print(self.fec_df.count())


    def normalize_name(self):
        for i in config['mapping_json']:
            if "split" in config['mapping_json'][i]:
                col_name = config['mapping_json'][i]["name"]
                lastname = config['mapping_json'][i]["split"][0]
                firstname = config['mapping_json'][i]["split"][1]
                split_col = f.split(self.fec_df[col_name], ',')
                self.fec_df = self.fec_df.withColumn(lastname, split_col.getItem(0))
                self.fec_df = self.fec_df.withColumn(firstname, split_col.getItem(1))

    def normalize_date(self):

        for i in config['mapping_json']:
            if config['mapping_json'][i]["type"] == "timestamp":
                col_name = config['mapping_json'][i]["name"]
                self.fec_df = self.fec_df.withColumn(col_name,
                                                     to_timestamp(self.fec_df[col_name], "MMddyyyy").cast("string"))

    @staticmethod
    def validate_state(data):
        state_check=""
        try:
            state_check = us.states.lookup(data["State"])
            if state_check !="":
                data['State_Validation'] = "true"
            else:
                data["State_Validation"] = "false"
            return  data
        except:
            return data

    def normalize_state(self):
        validate_fec_data_rdd = self.fec_df.rdd.map(lambda row: Fec_Normalizer.validate_state(row.asDict()))
        self.fec_df = self.spark.createDataFrame(validate_fec_data_rdd, self.fec_df.schema)

        #self.final_fec_df = self.fec_df.filter(self.fec_df["State_Validation"] == "true")
        #self.anonymous_state_df = self.fec_df.filter(self.fec_df["State_Validation"] == "false")
        #self.fec_df = self.final_fec_df


    def unique_identity(self):


        self.fec_df = self.fec_df.withColumn("Profile_ID", sha2(concat_ws("||", *["City", "State", "ZIP_code",
                                                                                       "Employer", "Occupation",
                                                                                       "Contributor_Lender_Transfer_Name"]),256))
        #self.group_df = self.fec_df.groupBy("City", "State", "ZIP_code", "Employer", "Occupation",
         #                                   "Contributor_Lender_Transfer_Name").count()
        #self.group_df = self.group_df.withColumn("Profile_ID", sha2(concat_ws("||", *self.group_df.columns), 256))
        #self.fec_df = self.fec_df.join(self.group_df, ["City", "State", "ZIP_code", "Employer", "Occupation",
        #                                          "Contributor_Lender_Transfer_Name"], "left_outer")
        #self.fec_df.show(20, truncate=False)
        #self.group_df.unpersist()
        #self.anonymous_state_df.show(40, truncate=False)


    def write_data_file(self):
        a = datetime.datetime.now()
        print("write_data_file")
        #print(self.fec_df.count())
        #for writing data in csv format

        #self.fec_df.write.csv(path=self.output_path, header="true", mode="append")
        self.fec_df.coalesce(5).write.csv(path=self.output_path, header="true", mode="append")


        #self.fec_df.write.format("csv").mode("append").save(self.output_path)

        #for writing data into partitioned parquet format
        #self.fec_df.write.partitionBy(self.partition_column).format("parquet").mode("append").save(self.output_path)

        #for writing Anonymous data
        #self.anonymous_state_df.write.format("parquet").mode("append").save(self.s3_anonymous_state_output_path)
        b = datetime.datetime.now()
        print(b-a)

    def close(self):
        self.spark.stop()
